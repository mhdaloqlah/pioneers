import React from "react";
import "./People.css";
const People = () => {
  return <div>People</div>;
};

export default People;
